<?php
include 'db_connect.php';

$updates = [
    'Physics' => ['Mechanics', 'Thermodynamics', 'Atomic Physics', 'Electromagnetism'],
    'Chemistry' => ['Organic', 'Inorganic', 'Physical', 'Biochemistry'],
    'IT' => ['Programming', 'Databases', 'Networking', 'Web Dev'],
    'Mathematics' => ['Calculus', 'Algebra', 'Statistics', 'Geometry'],
    'English' => ['Literature', 'Grammar', 'Communication', 'Linguistics']
];

echo "Starting Date Fix...<br>";

foreach ($updates as $dept => $subjects) {
    echo "Fixing $dept...<br>";
    foreach ($subjects as $subject) {
        $sql = "UPDATE books SET department = :dept WHERE subject = :subject";
        $stmt = $conn->prepare($sql);
        $stmt->bindParam(':dept', $dept);
        $stmt->bindParam(':subject', $subject);
        if ($stmt->execute()) {
             $count = $stmt->rowCount();
             if ($count > 0) echo "Updated $count books for subject '$subject' to '$dept'<br>";
        }
    }
}
echo "Done.";
?>
