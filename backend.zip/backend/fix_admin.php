<?php
include 'db_connect.php';

$email = 'ahmad@gmail.com';
$stmt = $conn->prepare("UPDATE users SET role = 'Super Admin', status = 'approved' WHERE email = :email");
$stmt->bindParam(':email', $email);

if ($stmt->execute()) {
    echo "Updated " . $stmt->rowCount() . " rows. User $email is now Super Admin.";
} else {
    echo "Update failed.";
}
?>
