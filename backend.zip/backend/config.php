<?php
// Database Configuration
$host = "localhost";
$db_name = "chaudhar_lib";
$username = "chaudhar_ahmad";
$password = "12345678Ahmad!";
?>
